package lab4;

import lab4.swingApp.GameFrame;

public class Main {

    public static void main(String[] args) {

        GameFrame frame = new GameFrame();
        
    }
}
